<p align="center"> ![http://nahrup.ir/view/876/adv-v4.png](http://nahrup.ir/view/876/adv-v4.png)
<h1 align="left">`[⚓️](AdvanSource`, _bot with fast speed and high power)_</h1><p align=centert">  <p align="left">[![Join the chat at https://gitter.im/janlou/AdvanSource](https://badges.gitter.im/AdvanSource.svg)](https://gitter.im/janlou/AdvanSource?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
<h4> It is an anti spam bot (CLI) with fast speed and free for you! based on [TeleSeed](https://github.com/SEEDTEAM/TeleSeed) and powered by [ADVAN™](http://telegram.me/advantm), this source have an original *Autolaunch* and *Steady script* for your ubuntu server.
***
<p align="left">Creator: [[ JOIN! ]](https://telegram.me/advanbot)
<p align="left">Channel: [[ JOIN! ]](https://telegram.me/joinchat/CbNIGj07Z0YAy3CX5MRQaQ)
<p align="left">Support: [[ JOIN! ]](https://telegram.me/joinchat/Bqy_YT_BXhTWrPiN97yvsg)
***
## You can create an account for free in:
|Rank | Name | Adress |
|:--------|:----------|:------------|
| <h4>`Rank` _(1)_ | Codenvy | [https://codenvy.com](https://codenvy.com) |
| <h4>`Rank` _(2)_ | Codeanywhere | [https://codeanywhere.com](https://codeanywhere.com) |
| <h4>`Rank` _(3)_ | Cloud9 | [https://C9.io](https://C9.io) |
| <h4>`Rank` _(4)_ | Koding | [https://koding.com](https://koding.com) |
| <h4>`Rank` _(5)_ | SourceLair | [https://www.sourcelair.com/home](https://www.sourcelair.com) |
| <h4>`Rank` _(6)_ | Nitrous | [https://www.nitrous.io/](https://www.nitrous.io) |

##Strong management:
- <p align="left">Lock link
- <p align="left">Lock spam
- <p align="left">Lock flood
- <p align="left">Lock media
- <p align="left">Lock bots
- <p align="left">Lock forward(fwd)
- <p align="left">Lock reply
- <p align="left">Lock share
- <p align="left">Lock tag
- <p align="left">Lock number
- <p align="left">Lock poker
- <p align="left">Lock audio
- <p align="left">Lock video
- <p align="left">Lock gifs
- <p align="left">Lock documents
- <p align="left">Lock photo
- <p align="left">Lock all
- <p align="left">Lock text
- <p align="left">Lock inline
- <p align="left">Lock cmd
- <p align="left">Lock sticker
- <p align="left">Lock rtl
- <p align="left">Lock strict
- <p align="left">Lock tgservice
- <p align="left">Public & members
- <p align="left">Show mutes list in settings
- <p align="left">And ...

## SuperGroup's languages (you can say !lang list):
| Commands | Usage | 
|:--------|:----------|:------------|
| <h4>[!#/]setlang `en` | Change launguage of supergroup to `enlish` when you are in a supergroup |
| <h4>[!#/]setlang `fa` | تغییر زبان سوپرگروه به `فارسی با دستورات انگلیسی` زمانیکه شما در سوپرگروه میباشید |
| <h4>[!#/]setlang `فا` | تغییر زبان سوپرگروه `فارسی با دستورات فارسی` زمانیکه شما در سوپرگروه میباشید |
## Chat's languages:
| Commands | Usage | 
|:--------|:----------|:------------|
| <h4>[!#/]setlang `en` | Change launguage of chat to `enlish` when you are in a chat |
| <h4>[!#/]setlang `fa` | تغییر زبان چت به `فارسی با دستورات انگلیسی` زمانیکه شما در چت میباشید |
| <h4>[!#/]setlang `فا` | تغییر زبان چت `فارسی با دستورات فارسی` زمانیکه شما در چت میباشید |

| INSTALL BOT |
|:-----------------------|
- <p align="left">Clone Source:
```sh
git clone https://github.com/janlou/AdvanSource && cd AdvanSource
```
- <p align="left">install bot:
```sh
chmod 700 start.sh
./start.sh install
y
```
| ANTI CRASH |
|:-----------------------|
```sh
tmux new-session -s script "bash steady.sh -t"
```
- <p align="left">Now run your bot then enter bot's phone number and join code:
`./start.sh -q`
- <p align="left">And you can start bot with steady script:

| FREE SERVER: |
|:-----------------------|
| `./steady.sh -t` |

| BOUGHT SERVER: |
|:-----------------------|
| `screen ./steady.sh -t` |
